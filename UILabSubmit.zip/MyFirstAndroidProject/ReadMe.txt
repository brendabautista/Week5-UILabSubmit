This program is just an application from a youtube demonstration video about creating Android program.
The program can't be tested because the Virtual testing always freezes.
I do understand the concepts and some parts of the application but can't fully try due to low computer specifications that makes my Android Studio program freezes.